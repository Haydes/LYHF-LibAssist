/**
 *
 */

function keyLogin(event) {

    var browser = navigator.appName;
    var userAgent = navigator.userAgent;
    var code;
    if(browser.indexOf('Internet')>-1) //IE
    code = window.event.keyCode;
    else if(userAgent.indexOf("Firefox")>-1)
    code = event.which;
    else
    code = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;

    if ( code == 13)
        document.getElementById("btn_login").click();  
}


window.onload = function () {
    var btn_login = document.getElementById('btn_login');
    var btn_register = document.getElementById('btn_register');


    btn_login.onclick = function login() {

        var username = document.getElementById("username");
        var pass = document.getElementById("password");

        if (username.value == "") {

            alert("Please enter Username");

        } else if (pass.value == "") {

            alert("please enter password");

        } else if (username.value == "LYHF" && pass.value == "111111") {

            window.location.href = "welcome.html";

            ////
            //function fullScreen(element) {
            //    if (element.requestFullscreen) {
            //        element.requestFullscreen();
            //    } else if (element.mozRequestFullScreen) {
            //        element.mozRequestFullScreen();
            //    } else if (element.webkitRequestFullscreen) {
            //        element.webkitRequestFullscreen();
            //    } else if (element.msRequestFullscreen) {
            //        element.msRequestFullscreen();
            //    }
            //}
            ////  再让当前页面全屏
            //fullScreen(document.documentElement);

        } else {

            alert("Please enter correct username or password!");

        }
    }

    btn_register.onclick = function register() {
        window.open("register.html");
    }
}


